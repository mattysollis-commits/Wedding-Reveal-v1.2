import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AuthPage } from './components/AuthPage';
import { RevealPage } from './components/RevealPage';
import { AdminPanel } from './components/AdminPanel';

function AppContent() {
  const { user, loading, isAdmin } = useAuth();
  const [isAdminRoute, setIsAdminRoute] = useState(false);

  useEffect(() => {
    const sync = () => setIsAdminRoute(window.location.pathname === '/admin');
    sync();

    const handlePopState = () => sync();
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-rose-400 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  if (isAdminRoute) {
    return <AdminPanel />;
  }

  // If an admin logs in and isn't on /admin, we can send them there automatically.
  if (isAdmin && window.location.pathname !== '/admin') {
    window.history.replaceState({}, '', '/admin');
    return <AdminPanel />;
  }

  return <RevealPage />;
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
