import { createContext, useContext, useEffect, useMemo, useState } from 'react';

type AppRole = 'bestman' | 'groomsman' | 'admin';

export interface LocalUser {
  id: string;
  username: string;
}

export interface LocalUserRole {
  id: string;
  user_id: string;
  username: string;
  role: Exclude<AppRole, 'admin'>;
  revealed: boolean;
  created_at: string;
}

interface AuthContextType {
  user: LocalUser | null;
  userRole: LocalUserRole | null;
  isAdmin: boolean;
  loading: boolean;
  /** Login using one of the pre-configured usernames (no email / no sign up). */
  signIn: (username: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  markAsRevealed: () => Promise<void>;
  /** Admin helpers */
  listAccounts: () => { username: string; role: AppRole; revealed: boolean }[];
  setRevealed: (username: string, revealed: boolean) => void;
  resetAllReveals: () => void;
}

/**
 * Configure your 4 accounts here.
 * - Change usernames/passwords before deploying.
 * - One account can be admin (optional), used for /admin route.
 */
const ACCOUNTS: Array<{ username: string; password: string; role: AppRole }> = [
  { username: 'admin', password: 'change-me-admin', role: 'admin' },
  { username: 'bestman', password: 'change-me-1', role: 'bestman' },
  { username: 'groomsman1', password: 'change-me-2', role: 'groomsman' },
  { username: 'groomsman2', password: 'change-me-3', role: 'groomsman' },
];

const STORAGE_KEY = 'wr_auth_session_v1';
const REVEAL_KEY_PREFIX = 'wr_revealed_';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function nowIso() {
  return new Date().toISOString();
}

function getAccount(username: string) {
  return ACCOUNTS.find(a => a.username.toLowerCase() === username.toLowerCase());
}

function getRevealKey(username: string) {
  return `${REVEAL_KEY_PREFIX}${username.toLowerCase()}`;
}

function getRevealed(username: string): boolean {
  try {
    return localStorage.getItem(getRevealKey(username)) === 'true';
  } catch {
    return false;
  }
}

function setRevealed(username: string, revealed: boolean) {
  try {
    localStorage.setItem(getRevealKey(username), String(revealed));
  } catch {
    // ignore
  }
}

function readSession(): { username: string } | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed.username === 'string') return { username: parsed.username };
    return null;
  } catch {
    return null;
  }
}

function writeSession(username: string | null) {
  try {
    if (!username) {
      localStorage.removeItem(STORAGE_KEY);
      return;
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ username }));
  } catch {
    // ignore
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<LocalUser | null>(null);
  const [userRole, setUserRole] = useState<LocalUserRole | null>(null);
  const [loading, setLoading] = useState(true);

  const isAdmin = useMemo(() => {
    const acct = user ? getAccount(user.username) : null;
    return acct?.role === 'admin';
  }, [user]);

  const hydrateFromUsername = (username: string | null) => {
    if (!username) {
      setUser(null);
      setUserRole(null);
      return;
    }
    const acct = getAccount(username);
    if (!acct) {
      setUser(null);
      setUserRole(null);
      return;
    }

    const localUser: LocalUser = { id: `local:${acct.username.toLowerCase()}`, username: acct.username };
    setUser(localUser);

    if (acct.role === 'admin') {
      setUserRole(null);
    } else {
      setUserRole({
        id: `role:${acct.username.toLowerCase()}`,
        user_id: localUser.id,
        username: acct.username,
        role: acct.role,
        revealed: getRevealed(acct.username),
        created_at: nowIso(),
      });
    }
  };

  useEffect(() => {
    const session = readSession();
    hydrateFromUsername(session?.username ?? null);
    setLoading(false);
  }, []);

  const signIn = async (username: string, password: string) => {
    const acct = getAccount(username);
    if (!acct || acct.password !== password) {
      return { error: 'Invalid username or password.' };
    }

    writeSession(acct.username);
    hydrateFromUsername(acct.username);
    return { error: null };
  };

  const signOut = async () => {
    writeSession(null);
    setUser(null);
    setUserRole(null);
  };

  const markAsRevealed = async () => {
    if (!user || !userRole) return;
    setRevealed(user.username, true);
    setUserRole({ ...userRole, revealed: true });
  };

  const listAccounts = () => {
    return ACCOUNTS.filter(a => a.role !== 'admin').map(a => ({
      username: a.username,
      role: a.role,
      revealed: getRevealed(a.username),
    }));
  };

  const setRevealedForUser = (username: string, revealed: boolean) => {
    setRevealed(username, revealed);
    if (user?.username.toLowerCase() === username.toLowerCase() && userRole) {
      setUserRole({ ...userRole, revealed });
    }
  };

  const resetAllReveals = () => {
    ACCOUNTS.forEach(a => {
      if (a.role !== 'admin') setRevealed(a.username, false);
    });
    if (user && userRole) setUserRole({ ...userRole, revealed: false });
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userRole,
        isAdmin,
        loading,
        signIn,
        signOut,
        markAsRevealed,
        listAccounts,
        setRevealed: setRevealedForUser,
        resetAllReveals,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
