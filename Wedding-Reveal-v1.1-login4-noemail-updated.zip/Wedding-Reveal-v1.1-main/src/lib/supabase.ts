import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface UserRole {
  id: string;
  user_id: string;
  email: string;
  role: 'bestman' | 'groomsman';
  revealed: boolean;
  created_at: string;
}
