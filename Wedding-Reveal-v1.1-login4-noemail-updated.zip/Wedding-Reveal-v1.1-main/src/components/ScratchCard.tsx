import { useEffect, useRef, useState } from 'react';
import { Sparkles } from 'lucide-react';

interface ScratchCardProps {
  role: 'bestman' | 'groomsman';
  onReveal: () => void;
}

export function ScratchCard({ role, onReveal }: ScratchCardProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isScratching, setIsScratching] = useState(false);
  const [scratchPercentage, setScratchPercentage] = useState(0);
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * 2;
    canvas.height = rect.height * 2;
    ctx.scale(2, 2);

    const gradient = ctx.createLinearGradient(0, 0, rect.width, rect.height);
    gradient.addColorStop(0, '#c0c0c0');
    gradient.addColorStop(0.5, '#e0e0e0');
    gradient.addColorStop(1, '#a0a0a0');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, rect.width, rect.height);

    ctx.fillStyle = '#666';
    ctx.font = 'bold 24px serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Scratch Here', rect.width / 2, rect.height / 2);
  }, []);

  const calculateScratchPercentage = () => {
    const canvas = canvasRef.current;
    if (!canvas) return 0;

    const ctx = canvas.getContext('2d');
    if (!ctx) return 0;

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    let transparentPixels = 0;

    for (let i = 3; i < pixels.length; i += 4) {
      if (pixels[i] < 128) {
        transparentPixels++;
      }
    }

    return (transparentPixels / (pixels.length / 4)) * 100;
  };

  const scratch = (x: number, y: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(
      (x - rect.left) * scaleX,
      (y - rect.top) * scaleY,
      30 * Math.min(scaleX, scaleY),
      0,
      2 * Math.PI
    );
    ctx.fill();

    const percentage = calculateScratchPercentage();
    setScratchPercentage(percentage);

    if (percentage > 50 && !revealed) {
      setRevealed(true);
      onReveal();
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsScratching(true);
    scratch(e.clientX, e.clientY);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isScratching) {
      scratch(e.clientX, e.clientY);
    }
  };

  const handleMouseUp = () => {
    setIsScratching(false);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    e.preventDefault();
    setIsScratching(true);
    const touch = e.touches[0];
    scratch(touch.clientX, touch.clientY);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    e.preventDefault();
    if (isScratching) {
      const touch = e.touches[0];
      scratch(touch.clientX, touch.clientY);
    }
  };

  const handleTouchEnd = () => {
    setIsScratching(false);
  };

  const roleText = role === 'bestman' ? 'Best Man' : 'Groomsman';
  const roleColor = role === 'bestman' ? 'from-amber-400 to-yellow-600' : 'from-blue-400 to-blue-600';

  return (
    <div className="relative w-full max-w-md mx-auto">
      <div className={`absolute inset-0 bg-gradient-to-br ${roleColor} rounded-2xl flex flex-col items-center justify-center p-8 shadow-2xl`}>
        <Sparkles className="w-16 h-16 text-white mb-4 animate-pulse" />
        <h2 className="text-4xl font-bold text-white text-center mb-2">
          You're the
        </h2>
        <h1 className="text-5xl font-extrabold text-white text-center">
          {roleText}!
        </h1>
        {role === 'bestman' && (
          <p className="text-white text-center mt-4 text-lg">
            Time to plan an epic celebration!
          </p>
        )}
        {role === 'groomsman' && (
          <p className="text-white text-center mt-4 text-lg">
            Let's make this wedding unforgettable!
          </p>
        )}
      </div>
      <canvas
        ref={canvasRef}
        className="relative w-full h-96 rounded-2xl cursor-pointer touch-none"
        style={{ touchAction: 'none' }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      />
      <div className="mt-4 text-center text-gray-600">
        {scratchPercentage < 50 ? (
          <p>Scratch to reveal your role!</p>
        ) : (
          <p className="font-semibold text-green-600">Revealed!</p>
        )}
      </div>
    </div>
  );
}
