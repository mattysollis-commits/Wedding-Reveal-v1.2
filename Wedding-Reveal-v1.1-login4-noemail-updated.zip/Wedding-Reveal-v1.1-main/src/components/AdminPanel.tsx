import { useMemo, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Crown, RefreshCw, LogOut, CheckCircle2, XCircle } from 'lucide-react';

export function AdminPanel() {
  const { isAdmin, listAccounts, setRevealed, resetAllReveals, signOut } = useAuth();
  const [message, setMessage] = useState<string>('');

  const accounts = useMemo(() => listAccounts(), [listAccounts]);

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-400 rounded-full flex items-center justify-center mx-auto mb-4">
            <Crown className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Admin Only</h2>
          <p className="text-gray-600 mb-6">
            Please log in with the admin account to access this page.
          </p>
          <button
            onClick={() => (window.location.href = '/')}
            className="bg-gradient-to-r from-rose-400 to-orange-400 text-white font-semibold py-2 px-6 rounded-lg hover:from-rose-500 hover:to-orange-500 transition-all shadow-lg hover:shadow-xl"
          >
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  const handleResetAll = () => {
    resetAllReveals();
    setMessage('All reveals have been reset.');
    setTimeout(() => setMessage(''), 2500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 p-4">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-orange-400 rounded-xl flex items-center justify-center mr-4">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Admin Panel</h1>
                <p className="text-gray-600 text-sm">Manage reveal status for each account</p>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleResetAll}
                className="inline-flex items-center bg-gray-900 text-white font-semibold py-2 px-4 rounded-lg hover:bg-gray-800 transition-all"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Reset all
              </button>
              <button
                onClick={signOut}
                className="inline-flex items-center bg-white border border-gray-200 text-gray-800 font-semibold py-2 px-4 rounded-lg hover:bg-gray-50 transition-all"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign out
              </button>
            </div>
          </div>

          {message && (
            <div className="mt-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">
              {message}
            </div>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100">
            <h2 className="text-lg font-bold text-gray-900">Accounts</h2>
          </div>

          <div className="divide-y divide-gray-100">
            {accounts.map((a) => (
              <div key={a.username} className="p-6 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-gray-900">{a.username}</div>
                  <div className="text-sm text-gray-600">
                    Role: <span className="font-medium">{a.role === 'bestman' ? 'Best Man' : 'Groomsman'}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {a.revealed ? (
                    <span className="inline-flex items-center text-sm font-semibold text-green-700 bg-green-50 border border-green-200 px-3 py-1 rounded-full">
                      <CheckCircle2 className="w-4 h-4 mr-1" />
                      Revealed
                    </span>
                  ) : (
                    <span className="inline-flex items-center text-sm font-semibold text-gray-700 bg-gray-50 border border-gray-200 px-3 py-1 rounded-full">
                      <XCircle className="w-4 h-4 mr-1" />
                      Not revealed
                    </span>
                  )}

                  <button
                    onClick={() => setRevealed(a.username, !a.revealed)}
                    className="bg-gradient-to-r from-rose-400 to-orange-400 text-white font-semibold py-2 px-4 rounded-lg hover:from-rose-500 hover:to-orange-500 transition-all shadow-md hover:shadow-lg"
                  >
                    {a.revealed ? 'Mark not revealed' : 'Mark revealed'}
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="px-6 py-4 bg-gray-50 text-xs text-gray-600">
            Tip: To change usernames/passwords, edit <span className="font-mono">src/contexts/AuthContext.tsx</span> (ACCOUNTS).
          </div>
        </div>
      </div>
    </div>
  );
}
