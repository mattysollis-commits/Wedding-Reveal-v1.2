import { useAuth } from '../contexts/AuthContext';
import { ScratchCard } from './ScratchCard';
import { LogOut, Sparkles } from 'lucide-react';

export function RevealPage() {
  const { user, userRole, signOut, markAsRevealed } = useAuth();

  if (!userRole) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-400 rounded-full flex items-center justify-center mx-auto mb-4">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Role Not Assigned Yet
          </h2>
          <p className="text-gray-600 mb-6">
            Your account has been created! Please ask the wedding host to assign your role. Once assigned, refresh this page to see your scratchcard.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="bg-gradient-to-r from-rose-400 to-orange-400 text-white font-semibold py-2 px-6 rounded-lg hover:from-rose-500 hover:to-orange-500 transition-all shadow-lg hover:shadow-xl mb-4"
          >
            Refresh Page
          </button>
          <button
            onClick={signOut}
            className="block w-full text-gray-600 hover:text-gray-900 font-medium"
          >
            <LogOut className="w-4 h-4 inline mr-2" />
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  if (userRole.revealed) {
    const roleText = userRole.role === 'bestman' ? 'Best Man' : 'Groomsman';
    const roleColor = userRole.role === 'bestman' ? 'from-amber-400 to-yellow-600' : 'from-blue-400 to-blue-600';

    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full">
          <div className={`bg-gradient-to-br ${roleColor} rounded-2xl shadow-2xl p-8 text-center mb-6`}>
            <Sparkles className="w-16 h-16 text-white mx-auto mb-4 animate-pulse" />
            <h2 className="text-3xl font-bold text-white mb-2">
              You're the
            </h2>
            <h1 className="text-5xl font-extrabold text-white mb-4">
              {roleText}!
            </h1>
            {userRole.role === 'bestman' && (
              <p className="text-white text-lg">
                Time to plan an epic celebration!
              </p>
            )}
            {userRole.role === 'groomsman' && (
              <p className="text-white text-lg">
                Let's make this wedding unforgettable!
              </p>
            )}
          </div>
          <button
            onClick={signOut}
            className="w-full bg-white text-gray-700 font-medium py-3 px-4 rounded-lg hover:bg-gray-50 transition-all shadow-md hover:shadow-lg"
          >
            <LogOut className="w-4 h-4 inline mr-2" />
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50 flex flex-col items-center justify-center p-4">
      <div className="max-w-2xl w-full mb-8 text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Welcome, {user?.email}!
        </h1>
        <p className="text-lg text-gray-600 mb-2">
          You've been invited to be part of something special.
        </p>
        <p className="text-gray-600">
          Scratch the card below to reveal your role in the wedding!
        </p>
      </div>

      <ScratchCard role={userRole.role} onReveal={markAsRevealed} />

      <button
        onClick={signOut}
        className="mt-8 text-gray-600 hover:text-gray-900 font-medium transition-colors"
      >
        <LogOut className="w-4 h-4 inline mr-2" />
        Sign Out
      </button>
    </div>
  );
}
