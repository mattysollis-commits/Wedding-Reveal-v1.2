/*
  # Create user roles table for wedding reveal

  1. New Tables
    - `user_roles`
      - `id` (uuid, primary key) - Unique identifier for the record
      - `user_id` (uuid, foreign key) - References auth.users
      - `email` (text) - User's email for easy lookup
      - `role` (text) - Either 'bestman' or 'groomsman'
      - `revealed` (boolean) - Whether the user has scratched their card
      - `created_at` (timestamptz) - When the record was created
  
  2. Security
    - Enable RLS on `user_roles` table
    - Add policy for authenticated users to read only their own role
    - Add policy for authenticated users to update only their own revealed status
  
  3. Important Notes
    - Each user can only have one role
    - Users can only see their own role, not others'
    - Users can mark their card as revealed but cannot change their role
*/

CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  email text NOT NULL,
  role text NOT NULL CHECK (role IN ('bestman', 'groomsman')),
  revealed boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own role"
  ON user_roles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own revealed status"
  ON user_roles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_email ON user_roles(email);